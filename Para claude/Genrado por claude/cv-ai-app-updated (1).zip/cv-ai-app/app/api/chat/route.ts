import { NextRequest, NextResponse } from 'next/server'
import { createServerClient } from '@supabase/ssr'
import { cookies } from 'next/headers'
import { anthropic } from '@/lib/ai/claude'
import { extractProfileUpdate, mergeProfileData } from '@/lib/ai/profile-extractor'

function extractQuestionsAsked(messages: any[]): string[] {
  const questions: string[] = []
  messages.forEach(msg => {
    const match = msg.content.match(/nueva_pregunta_hecha":\s*"([^"]+)"/)
    if (match) questions.push(match[1])
  })
  return [...new Set(questions)] // Eliminar duplicados
}
export async function POST(request: NextRequest) {
  try {
    const { message } = await request.json()

    if (!message || typeof message !== 'string') {
      return NextResponse.json({ error: 'Mensaje inválido' }, { status: 400 })
    }

    const cookieStore = await cookies()
    const supabase = createServerClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
      {
        cookies: {
          getAll() { return cookieStore.getAll() },
          setAll(cookiesToSet) {
            cookiesToSet.forEach(({ name, value, options }) =>
              cookieStore.set(name, value, options)
            )
          },
        },
      }
    )

    const { data: { user }, error: authError } = await supabase.auth.getUser()
    if (authError || !user) {
      return NextResponse.json({ error: 'No autenticado' }, { status: 401 })
    }

    const { data: profileData } = await supabase
      .from('professional_profiles')
      .select('data, campos_pendientes')
      .eq('id', user.id)
      .single()

    const { data: basicProfile } = await supabase
      .from('profiles')
      .select('first_name')
      .eq('id', user.id)
      .single()
      const { data: chatHistory } = await supabase
  .from('chat_messages')
  .select('role, content')
  .eq('user_id', user.id)
  .order('created_at', { ascending: false })
  .limit(10)

const allMessages = (chatHistory ?? []).reverse()
const preguntasHechas = extractQuestionsAsked(allMessages)

// Últimos 3 intercambios (6 mensajes) para contexto conversacional — sin bloques PROFILE_UPDATE
const recentMessages = allMessages.slice(-6).map((msg: { role: string; content: string }) => ({
  role: msg.role as 'user' | 'assistant',
  content: msg.role === 'assistant'
    ? msg.content.replace(/\[PROFILE_UPDATE\][\s\S]*?\[\/PROFILE_UPDATE\]/g, '').trim()
    : msg.content,
}))

    const currentProfile = profileData?.data ?? {}
    const camposPendientes = profileData?.campos_pendientes ?? [
      'resumen_profesional', 'experiencia', 'educacion', 'habilidades', 'idiomas'
    ]
    const firstName = basicProfile?.first_name ?? 'tú'

    const systemPrompt = `Eres un extractor de información profesional. Tu único trabajo es completar el perfil del usuario haciendo preguntas cortas y directas cuando faltan datos útiles para un CV.

PERFIL ACTUAL (${firstName}):
${JSON.stringify(currentProfile, null, 2)}

CAMPOS PENDIENTES: ${camposPendientes.join(', ')}

PREGUNTAS YA HECHAS — NUNCA REPITAS ESTAS:
${JSON.stringify(preguntasHechas)}

REGLAS ABSOLUTAS (violarlas es un error crítico):

LONGITUD: Tu respuesta visible es máximo 1-2 líneas. Sin excepciones.

REPETICIÓN: No repitas ni resumas lo que el usuario dijo. Asume que quedó guardado y avanza.

RE-PREGUNTAR: Si el usuario ya respondió algo — aunque sea vagamente — no vuelvas a ese tema. Si fue ambiguo, pide aclaración en una línea y avanza.

SALUDOS: Solo en el primer mensaje (cuando el perfil está completamente vacío). Nunca más.

TONO: Directo. Sin "¡excelente!", sin "eso es muy valioso", sin frases motivacionales. Como un colega que toma notas.

PREGUNTAR: Solo haz UNA pregunta por mensaje. Solo si el dato faltante mejora concretamente el CV. Prioridad: logros con números > herramientas usadas > responsabilidades > educación > idiomas.

PROHIBIDO: No expliques por qué preguntas. No des consejos. No hagas eco de lo que el usuario dijo.

PRIMER MENSAJE (perfil vacío): Saluda por nombre en una línea y pregunta directamente "¿A qué te dedicas actualmente?" — nada más. No preguntes por idiomas, educación ni habilidades hasta tener experiencia laboral.

ESTRUCTURA DE RESPUESTA — siempre este formato exacto:

[texto visible: 1-2 líneas máximo]

[PROFILE_UPDATE]
{
  "cambios": {},
  "campos_actualizados": [],
  "nueva_pregunta_hecha": null
}
[/PROFILE_UPDATE]

Si hay datos nuevos, ponlos en "cambios" con la misma estructura del perfil. No inventes nada. En "nueva_pregunta_hecha" pon la clave del dato que preguntaste (ej: "logros_job_1", "herramientas_actuales") o null si no preguntaste.`;

    const response = await anthropic.messages.create({
      model: 'claude-haiku-4-5',
      max_tokens: 300,
      system: systemPrompt,
      messages: [...recentMessages, { role: 'user', content: message }],
    })

    const rawText = response.content[0].type === 'text' ? response.content[0].text : ''
    const { visibleText, profileUpdate } = extractProfileUpdate(rawText)

    if (profileUpdate && Object.keys(profileUpdate.cambios).length > 0) {
      const updatedData = mergeProfileData(currentProfile, profileUpdate.cambios)

      const newCamposPendientes = camposPendientes.filter(
        (campo: string) => !profileUpdate.campos_actualizados.includes(campo)
      )

      await supabase
        .from('professional_profiles')
        .upsert({
          id: user.id,
          data: updatedData,
          campos_pendientes: newCamposPendientes,
          last_updated_by_ai: new Date().toISOString(),
        })
    }

    await supabase.from('chat_messages').insert([
      { user_id: user.id, role: 'user', content: message, message_type: 'text' },
      { user_id: user.id, role: 'assistant', content: visibleText, message_type: 'text' },
    ])

    return NextResponse.json({ message: visibleText })

  } catch (error) {
    console.error('Error en /api/chat:', error)
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 })
  }
}